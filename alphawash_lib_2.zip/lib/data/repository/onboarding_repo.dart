import 'package:alphawash/data/datasource/remote/dio/dio_client.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

class OnBoardingRepo {
  final DioClient? dioClient;

  OnBoardingRepo({@required this.dioClient});

}
